
.. _constrain.PermittedAlphabetConstraint:

.. |Constraint| replace:: PermittedAlphabetConstraint

Permitted alphabet constraint
-----------------------------

.. autoclass:: pyasn1.type.constraint.PermittedAlphabetConstraint(*alphabet)
   :members:
